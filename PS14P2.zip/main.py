
class Car:

  def __init__(self, make, model, sticker, discount):
    self.make = make
    self.model = model
    self.sticker = sticker
    self.discount = discount

  def make(price):
    if make = sportswheels
      price = 1000.00
    if make = sportenginge
      price = 3000.00
    if make = sportinterior
      price = 2000.00
    b = float(price)
    return b

print(car_1.make)
print(car_1.model)
print(car_1.sticker)
print(car_1.price())
