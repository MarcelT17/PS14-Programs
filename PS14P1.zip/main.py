
class Employee:

  def __init__(self, first, last, pay):
    self.first = first
    self.last = last
    self.pay = pay
    self.email = first + '.' + last + '@company.com'

  def bonus(self,rate):
    b = float(rate) * float(self.pay)
    return b

  def bonus(self,rate)
    .40 * pay
  

empl1 = Employee('Marcel', 'Tegos',50000.00)

print(empl_1.email)
print(empl_1.first)
print(empl_1.last)
print(empl_1.pay)
print(empl_1.bonus())
